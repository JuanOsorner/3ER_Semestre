package com.plataforma.gestionestudiantil;


public class Main {
    public static void main(String[] args) {

    }
}