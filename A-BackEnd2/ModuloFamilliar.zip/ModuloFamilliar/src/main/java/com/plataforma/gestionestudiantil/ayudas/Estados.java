package com.plataforma.gestionestudiantil.ayudas;

public enum Estados {
    Activo,
    Inactivo,
    Especial
}

