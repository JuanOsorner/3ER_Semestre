package com.plataforma.gestionestudiantil.ayudas;

public enum Roles {
    Docente,
    Estudiante,
    Empresario

}
